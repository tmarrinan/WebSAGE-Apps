function bounce(){
	this.element = null;
	this.ctx = null;
	this.resrcPath = null;
	
	this.ballImg = null;
	this.vel = null;
	this.pos = null;
	this.dir = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.frame = null;
	
	this.init = function(id, date, resrc) {
		this.element = document.getElementById(id);
		this.ctx = this.element.getContext("2d");
		this.resrcPath = resrc;
		
		this.ballImg = new Image();
		this.ballImg.src = this.resrcPath + "images/evllogo.png";
		this.vel = 1.0;
		this.pos = [0.5, 0.5];
		this.dir = [0.7071, 0.7071];
		
		this.startDate = date;
		this.prevDate = date;
		this.frame = 0;
	};
	
	this.draw = function(date) {
		var t = (date.getTime() - this.startDate.getTime()) / 1000; // total time since start of program (sec)
		var dt = (date.getTime() - this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
		
	
		// clear canvas		
		this.ctx.clearRect(0,0, this.element.width, this.element.height);
		
		this.ctx.fillStyle = "rgba(0, 0, 0, 1.0)"
		this.ctx.fillRect(0,0, this.element.width, this.element.height)
		
		var minDim = Math.min(this.element.width, this.element.height);
		var wScale = 1.0;
		var hScale = 1.0;
		if(this.element.width < this.element.height) hScale = this.element.height / this.element.width;
		if(this.element.height < this.element.width) wScale = this.element.width / this.element.height;
		
		if(this.pos[0]<0 && this.dir[0]<0) this.dir[0] = -this.dir[0];
		if(this.pos[0]>1.0*wScale && this.dir[0]>0) this.dir[0] = -this.dir[0];
		if(this.pos[1]<0 && this.dir[1]<0) this.dir[1] = -this.dir[1];
		if(this.pos[1]>1.0*hScale && this.dir[1]>0) this.dir[1] = -this.dir[1];
		
		this.pos[0] += this.dir[0]*this.vel*dt;
		this.pos[1] += this.dir[1]*this.vel*dt;
		
		/*
		this.ctx.fillStyle="rgba(250, 60, 20, 1.0)";
		this.ctx.beginPath();
		this.ctx.arc(this.pos[0]*minDim, this.pos[1]*minDim, 0.1*minDim, 0, 2*Math.PI, true);
		this.ctx.closePath();
		this.ctx.fill();
		*/
		var size = 0.2*minDim;
		var x = this.pos[0]*minDim - (size/2);
		var y = this.pos[1]*minDim - (size/2);
		this.ctx.drawImage(this.ballImg, x, y, size, size);
		
		// update time variables
		//console.log("frame: " + this.frame + ", time: " + t + ", dt: " + dt);
		this.prevDate = date;
		this.frame++;
	};
}
