function three_sample() {
	this.divElement = null;
	this.resrcPath = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.frame = null;
	
	this.renderer = null;
	this.camera = null;
	this.scene = null;
	
	this.init = function(id, date, resrc) {
		this.divElement = document.getElementById(id);
		this.resrcPath = resrc;
		this.startDate = date;
		this.prevDate = date;
		this.frame = 0;
		
		this.renderer = new THREE.WebGLRenderer();
		this.camera = new THREE.PerspectiveCamera(45.0, this.divElement.width/this.divElement.height, 0.1, 10000.0);
		this.scene = new THREE.Scene();
		
		this.camera.position.z = 300;
		this.renderer.setSize(this.divElement.width, this.divElement.height);
		
		this.divElement.appendChild(this.renderer.domElement);
		
		var sphereMaterial = new THREE.MeshLambertMaterial({color: 0xCC0000});

		// set up the sphere variables
		var radius = 50;
		var segments = 16;
		var rings = 16;

		// create a new mesh with sphere geometry -
		// we will cover the sphereMaterial next!
		this.sphere = new THREE.Mesh(new THREE.SphereGeometry(radius, segments, rings), sphereMaterial);

		// add the sphere to the scene
		this.scene.add(this.sphere);

		// and the camera
		this.scene.add(this.camera);

		// create a point light
		this.pointLight = new THREE.PointLight( 0xFFFFFF );

		// set its position
		this.pointLight.position.x = 10;
		this.pointLight.position.y = 50;
		this.pointLight.position.z = 130;

		// add to the scene
		this.scene.add(this.pointLight);

		// draw!
		this.renderer.render(this.scene, this.camera);
	};
	
	this.draw = function(date) {
		var t = (date.getTime() - this.startDate.getTime()) / 1000; // total time since start of program (sec)
		var dt = (date.getTime() - this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
		
		var amplitude = 50;
		var period = 2.0; // in sec
		var centerY = 0;
		
		this.sphere.position.y = amplitude * Math.sin(t * 2*Math.PI / period) + centerY;
		
		this.renderer.render(this.scene, this.camera);
		
		this.prevDate = date;
		this.frame++;
	};
	
	this.resize = function(date) {
		this.renderer.setSize(this.divElement.width, this.divElement.height);
		this.draw(date);
	};
}
