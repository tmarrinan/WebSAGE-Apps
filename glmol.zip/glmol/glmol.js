
function readTextFile(file)
{
    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function ()
    {
        if(rawFile.readyState === 4)
        {
            if(rawFile.status === 200 || rawFile.status == 0)
            {
                var allText = rawFile.responseText;
            }
        }
    }
    rawFile.send(null);
}


function glmol() {
	this.divElement = null;
	this.resrcPath = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.frame = null;
	
	this.renderer = null;
	this.camera = null;
	this.scene = null;
	this.rot = null;
	this.axis = null;

	this.init = function(id, date, resrc) {
		this.divElement = document.getElementById(id);
		this.resrcPath = resrc;
		this.startDate = date;
		this.prevDate = date;
		this.frame = 0;
		this.rot = 0;
		this.axis = new THREE.Vector3(0,1,0);

		// this.renderer = new THREE.WebGLRenderer();
		// this.camera = new THREE.PerspectiveCamera(45.0, this.divElement.width/this.divElement.height, 0.1, 10000.0);
		// this.scene = new THREE.Scene();
		
		// this.camera.position.z = 300;
		// this.renderer.setSize(this.divElement.width, this.divElement.height);
		
		// this.divElement.appendChild(this.renderer.domElement);
		
		//this.molfile = this.resrcPath + "molecules/I3.pdb";
		this.molfile = this.resrcPath + "molecules/2DHB.pdb";
		this.moldata = null;

		this.molecule = new GLmol(id, true);

	    var rawFile = new XMLHttpRequest();
	    rawFile.open("GET", this.molfile, true);
	    var _this = this;
	    rawFile.onreadystatechange = function ()
	    {
	        if(rawFile.readyState === 4)
	        {
	            if(rawFile.status === 200 || rawFile.status == 0)
	            {
	                _this.moldata = rawFile.responseText;

					_this.molecule.defineRepresentation = function() {
					   var all = this.getAllAtoms();
					   var hetatm = this.removeSolvents(this.getHetatms(all));
					   this.colorByAtom(all, {});
					   this.colorByChain(all);
					   var asu = new THREE.Object3D();
					   
					   this.drawBondsAsStick(asu, hetatm, this.cylinderRadius, this.cylinderRadius);
					   this.drawBondsAsStick(asu, this.getResiduesById(this.getSidechains(this.getChain(all, ['A'])), [58, 87]), this.cylinderRadius, this.cylinderRadius);
					   this.drawBondsAsStick(asu, this.getResiduesById(this.getSidechains(this.getChain(all, ['B'])), [63, 92]), this.cylinderRadius, this.cylinderRadius);
					   this.drawCartoon(asu, all, this.curveWidth, this.thickness);

					   this.drawSymmetryMates2(this.modelGroup, asu, this.protein.biomtMatrices);
					   this.modelGroup.add(asu);
					};
					_this.molecule.loadMoleculeStr(undefined, _this.moldata);

	            }
	        }
	    }
	    rawFile.send(null);

		// and the camera
		//this.scene.add(this.camera);

		// draw!
		//this.renderer.render(this.scene, this.camera);
		this.molecule.show();
	};
	
	this.draw = function(date) {
		var t = (date.getTime() - this.startDate.getTime()) / 1000; // total time since start of program (sec)
		var dt = (date.getTime() - this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
	
		// Update
		this.molecule.rotationGroup.rotateOnAxis( this.axis, 0.01);
		//this.rot += 0.01;

		// Draw		
		//this.renderer.render(this.scene, this.camera);
		this.molecule.show();

		this.prevDate = date;
		this.frame++;
	};
	

   //    self.WIDTH = self.container.width() * self.aaScale;
   //    self.HEIGHT = self.container.height() * self.aaScale;
   //    self.ASPECT = self.WIDTH / self.HEIGHT;
   //    self.renderer.setSize(self.WIDTH, self.HEIGHT);
   //    self.camera.aspect = self.ASPECT;
   //    self.camera.updateProjectionMatrix();
   //    self.show();



	this.resize = function(date) {
		this.molecule.renderer.setSize(this.divElement.width, this.divElement.height);

		this.draw(date);
	};
}
