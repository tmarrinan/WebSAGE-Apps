function kinetic_animation(){
	this.divElement = null;
	this.stage = null;
	
	this.resrcPath = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.currDate = null;
	this.frame = null;
	
	this.init = function(id, date, resrc) {
		this.divElement = document.getElementById(id);
		this.resrcPath = resrc;
		this.startDate = date;
		this.prevDate = date;
		this.currDate = date;
		this.frame = 0;
		
		this.stage = new Kinetic.Stage({container: id, width: this.divElement.width, height: this.divElement.height});
		this.layer1 = new Kinetic.Layer();
		
		var minDim = Math.min(this.divElement.width, this.divElement.height);
		
		this.hexagon = new Kinetic.RegularPolygon({
			x: this.stage.getWidth() / 2,
			y: this.stage.getHeight() / 2,
			sides: 6,
			radius: 0.25*minDim,
			fill: 'red',
			stroke: 'black',
			strokeWidth: 0.01*minDim
		});

		this.layer1.add(this.hexagon);
		this.stage.add(this.layer1);
		
		var anim = new Kinetic.Animation(this.draw.bind(this), this.layer1);
		anim.start();
	};
	
	this.draw = function(frame) {
		var t = (this.currDate.getTime() - this.startDate.getTime()) / 1000; // total time since start of program (sec)
		var dt = (this.currDate.getTime() - this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
		
		this.stage.setWidth(this.divElement.width);
		this.stage.setHeight(this.divElement.height);
		
		var minDim = Math.min(this.divElement.width, this.divElement.height);
		
		var amplitude = this.divElement.width / 4;
		var period = 2.0; // in sec
		var centerX = this.divElement.width / 2;
		var centerY = this.divElement.height / 2;
		
		this.hexagon.setX(amplitude * Math.sin(t * 2*Math.PI / period) + centerX);
		this.hexagon.setY(centerY);
		this.hexagon.setRadius(0.25*minDim);
		this.hexagon.setStrokeWidth(0.01*minDim);
	};
	
	this.updateTime = function(date) {
		this.prevDate = this.currDate;
		this.currDate = date;
		this.frame++;
	};
}
