function kinetic_animation(){
	this.divElement = null;
	this.stage = null;
	
	this.resrcPath = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.currDate = null;
	this.frame = null;
	
	this.init = function(id, date, resrc) {
		this.divElement = document.getElementById(id);
		
		this.stage = new Kinetic.Stage({container: id, width: this.divElement.width, height: this.divElement.height});
		
		this.resrcPath = resrc;
		
		this.startDate = date;
		this.prevDate = date;
		this.currDate = date;
		this.frame = 0;
	};
	
	this.draw = function() {
		var _this = this;
		
		var layer = new Kinetic.Layer();
		
		var minDim = Math.min(this.divElement.width, this.divElement.height);
		
		var hexagon = new Kinetic.RegularPolygon({
			x: this.stage.getWidth() / 2,
			y: this.stage.getHeight() / 2,
			sides: 6,
			radius: 0.25*minDim,
			fill: 'red',
			stroke: 'black',
			strokeWidth: 0.01*minDim
		});

		layer.add(hexagon);
		this.stage.add(layer);

		var amplitude = 150;			
		var period = 2.0; // in sec
		var centerX = this.stage.getWidth() / 2;

		var anim = new Kinetic.Animation(function(frame) {
			var t = (_this.currDate.getTime() - _this.startDate.getTime()) / 1000; // total time since start of program (sec)
			var dt = (_this.currDate.getTime() - _this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
			
			_this.stage.setWidth(_this.divElement.width);
			_this.stage.setHeight(_this.divElement.height);
			
			var minDim = Math.min(_this.divElement.width, _this.divElement.height);
			
			var amplitude = _this.divElement.width / 4;
			var period = 2.0; // in sec
			var centerX = _this.divElement.width / 2;
			var centerY = _this.divElement.height / 2;
			
			hexagon.setX(amplitude * Math.sin(t * 2*Math.PI / period) + centerX);
			hexagon.setY(centerY);
			hexagon.setRadius(0.25*minDim);
			hexagon.setStrokeWidth(0.01*minDim);
		}, layer);

		anim.start();
	};
	
	this.updateTime = function(date) {
		this.prevDate = this.currDate;
		this.currDate = date;
		this.frame++;
	}
}
