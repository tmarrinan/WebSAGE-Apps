function kinetic_animation(){
	this.divElement = null;
	this.stage = null;
	this.layer1 = null;
	
	this.resrcPath = null;
	
	this.startDate = null;
	this.prevDate = null;
	this.frame = null;
	
	this.init = function(id, date, resrc) {
		this.divElement = document.getElementById(id);
		this.resrcPath = resrc;
		this.startDate = date;
		this.prevDate = date;
		this.frame = 0;
		
		this.stage = new Kinetic.Stage({container: id, width: this.divElement.width, height: this.divElement.height});
		this.layer1 = new Kinetic.Layer();
		
		this.stage.add(this.layer1);
	};
	
	this.draw = function(date) {
		var t = (date.getTime() - this.startDate.getTime()) / 1000; // total time since start of program (sec)
		var dt = (date.getTime() - this.prevDate.getTime()) / 1000; // delta time since last frame (sec)
		
		this.layer1.removeChildren();
		
		var minDim = Math.min(this.divElement.width, this.divElement.height);
		
		var amplitude = this.divElement.width / 4;
		var period = 2.0; // in sec
		var centerX = this.divElement.width / 2;
		var centerY = this.divElement.height / 2;
		
		var hexagon = new Kinetic.RegularPolygon({
			x: amplitude * Math.sin(t * 2*Math.PI / period) + centerX,
			y: centerY,
			sides: 6,
			radius: 0.25*minDim,
			fill: 'red',
			stroke: 'black',
			strokeWidth: 0.01*minDim
		});
		
		this.layer1.add(hexagon);
		
		this.stage.draw();
		
		this.prevDate = date;
		this.frame++;
	};
	
	this.resize = function(date) {
		this.stage.setWidth(this.divElement.width);
		this.stage.setHeight(this.divElement.height);
		this.draw(date);
	}
}
